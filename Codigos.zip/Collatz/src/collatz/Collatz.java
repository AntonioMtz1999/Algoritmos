/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package collatz;
import java.util.Scanner;
/**
 *
 * @author jaird
 */
public class Collatz {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int n;
        Scanner entrada =new Scanner(System.in);
        int i = 0;
        n=entrada.nextInt();
        while (n > 1)
        {
            n = (n % 2 == 0 ?
            (n / 2) : 
            (3 * n + 1)); 
            i++;
    }
     System.out.println(i);
        // TODO code application logic here
    }
}
