/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package kraprekar;
import java.util.Scanner;
/**
 *
 * @author jaird
 */
public class Kraprekar {
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner ingreso = new Scanner(System.in);
        int numero;
        System.out.print("Ingresa un numero: ");
        numero=ingreso.nextInt();
        while(numero!=1){
            if(numero%2==0){
                System.out.print(numero+",");
                numero=numero/2;
            }else{
                System.out.print(numero+",");
                numero=(numero*3)+1;
            }
            if(numero==1){
                System.out.print("1");
            }
        }
        // TODO code application logic here
    }
    
}
